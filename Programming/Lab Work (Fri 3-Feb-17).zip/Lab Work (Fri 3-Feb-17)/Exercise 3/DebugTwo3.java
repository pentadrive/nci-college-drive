public class DebugTwo3
// Demonstrates remainder and output
{
  public static void main(String args[])
  {
      double a , b, result;
      long c ;

      c = 7777777777777L;
      a = 99 ;
      b = 8 ;
      result = a % b;

      System.out.println("Divide " + a + " by " + b);
      System.out.println("remainder is " + result);
      System.out.println("c is a very large number:");
      System.out.println(c);
   }

}