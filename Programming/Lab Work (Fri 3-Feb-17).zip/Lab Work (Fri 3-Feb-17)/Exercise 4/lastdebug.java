/*
*Unformatted.java
*@author Frances Sheridan
*21/08/2012
*/

import java.util.*;
class lastdebug
{
public static void main(String args[])
{
Scanner keyboard;
keyboard = new Scanner(System.in);
final double X = 13.45;
final int Y=34;
double salary;
int num;

System.out.println("enter an integer less than 70:");
num = keyboard.nextInt();
salary=num*X;
System.out.println("Wages: "+salary);
System.out.println("X = "+X);
System.out.println("X + Y = "+(X+Y));
}}