public class DebugTwo1
{
   public static void main(String args[])
   {
      int oneInt = 315;
      double oneDouble = 12.4;

      System.out.println("The int is ");
      System.out.println(oneInt);
      System.out.println("The double is ");
      System.out.println(oneDouble);

   }
}